<?php

/**
 * Search Loop - Single Reply
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<?php bbp_get_template_part( 'loop', 'single-reply' ); ?>